package com.halounlock;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class HaloMusicHook implements IXposedHookLoadPackage {

    private static final String TARGET_PACKAGE = "com.android.settings";
    private static final String FETCHER_CLASS = "com.meizu.settings.light.music.MusicLightAppSettingsFetcher";
    private static final String SUPPORT_APP_CLASS = "com.meizu.settings.light.music.MusicLightAppSettingsFetcher$SupportApplication";
    private static final String TAG = "HaloMusicUnlock";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!lpparam.packageName.equals(TARGET_PACKAGE)) return;

        XposedBridge.log(TAG + ": Hooking " + TARGET_PACKAGE);

        // Hook the constructor of MusicLightAppSettingsFetcher
        // After it builds the whitelist, we inject all installed apps
        XposedHelpers.findAndHookConstructor(
            FETCHER_CLASS,
            lpparam.classLoader,
            "androidx.fragment.app.FragmentActivity",
            new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    try {
                        Object fetcher = param.thisObject;
                        Context context = (Context) XposedHelpers.getObjectField(fetcher, "mContext");

                        // Get the mSupportAppList field
                        Field supportAppListField = fetcher.getClass().getDeclaredField("mSupportAppList");
                        supportAppListField.setAccessible(true);
                        List supportAppList = (List) supportAppListField.get(fetcher);

                        // Get SupportApplication constructor
                        Class<?> supportAppClass = XposedHelpers.findClass(SUPPORT_APP_CLASS, lpparam.classLoader);
                        Constructor<?> constructor = supportAppClass.getDeclaredConstructor(String.class, int.class, int.class);
                        constructor.setAccessible(true);

                        // Get all installed packages
                        PackageManager pm = context.getPackageManager();
                        List<ApplicationInfo> installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA);

                        // Build list of already whitelisted package names
                        List<String> existingPackages = new ArrayList<>();
                        for (Object app : supportAppList) {
                            String pkg = (String) XposedHelpers.getObjectField(app, "packageName");
                            existingPackages.add(pkg);
                        }

                        // Inject ALL installed apps not already in the list
                        int injected = 0;
                        for (ApplicationInfo appInfo : installedApps) {
                            // Skip system apps and already whitelisted
                            if (existingPackages.contains(appInfo.packageName)) continue;
                            if ((appInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;

                            // Create new SupportApplication(packageName, 0, 0)
                            // 0 for title/icon res since we don't have them — Flyme handles display
                            Object newSupportApp = constructor.newInstance(appInfo.packageName, 0, 0);

                            // Set enabled = true
                            Field enabledField = supportAppClass.getDeclaredField("enabled");
                            enabledField.setAccessible(true);
                            enabledField.set(newSupportApp, true);

                            supportAppList.add(newSupportApp);
                            injected++;
                        }

                        XposedBridge.log(TAG + ": Injected " + injected + " apps into music light whitelist");

                    } catch (Throwable t) {
                        XposedBridge.log(TAG + ": Error - " + t.getMessage());
                    }
                }
            }
        );
    }
}
